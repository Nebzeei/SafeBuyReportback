export default function Home() {
  const telegramUsername = '@SafeBuy_Report';
  const STRIPE_LITE = 'https://buy.stripe.com/test_bJedRbboy0Sn8nRgG2f7i02';
  const STRIPE_STD  = 'https://buy.stripe.com/test_5kQeVfaku8kPdIb3Tgf7i00';
  const STRIPE_VIP  = 'https://buy.stripe.com/test_5kQ9AV78i58D6fJ89wf7i01';

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-30 backdrop-blur bg-white/70 border-b">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
          <a href="#home" className="font-semibold text-xl tracking-tight">SafeBuy Report</a>
          <nav className="hidden md:flex gap-6 text-sm">
            <a href="#come-funziona" className="hover:text-gray-700">Come funziona</a>
            <a href="#prezzi" className="hover:text-gray-700">Prezzi</a>
            <a href="#faq" className="hover:text-gray-700">FAQ</a>
            <a href="#contatti" className="hover:text-gray-700">Contatti</a>
          </nav>
          <a href={`https://t.me/${telegramUsername.replace('@','')}`} className="inline-flex items-center rounded-2xl px-4 py-2 text-sm font-medium bg-gray-900 text-white hover:bg-black transition">Apri Telegram</a>
        </div>
      </header>

      <section id="home" className="relative overflow-hidden">
        <div className="mx-auto max-w-6xl px-4 py-20 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-bold leading-tight">Compra sicuro: controlliamo noi prima che tu paghi</h1>
            <p className="mt-4 text-lg text-gray-600">Analizziamo venditori, siti e annunci (Subito, Marketplace, Vinted, IG). In pochi minuti ricevi su <b>Telegram</b> un verdetto chiaro: <i>OK</i> / <i>Rischio alto</i>, con motivi e consigli.</p>
            <div className="mt-6 flex gap-3">
              <a href="#prezzi" className="rounded-2xl px-5 py-3 bg-gray-900 text-white font-medium hover:bg-black transition">Scegli un pacchetto</a>
              <a href="#come-funziona" className="rounded-2xl px-5 py-3 border font-medium hover:bg-gray-50 transition">Come funziona</a>
            </div>
            <div className="mt-6 text-xs text-gray-500">Risposta media &lt; 20 minuti • Pagamenti Stripe • Nessun abbonamento</div>
          </div>
          <div className="md:pl-6">
            <div className="rounded-3xl border shadow-sm p-6">
              <div className="text-sm text-gray-500">Esempio di esito</div>
              <div className="mt-3 space-y-3">
                <div className="rounded-2xl border p-4">
                  <div className="text-xs text-gray-500">Richiesta #1842</div>
                  <div className="mt-1 font-semibold">Verdetto: ALTO RISCHIO</div>
                  <ul className="mt-2 text-sm text-gray-600 list-disc pl-5 space-y-1">
                    <li>Prezzo -45% sotto mercato</li>
                    <li>Dominio creato 2 settimane fa</li>
                    <li>Richiesta pagamento solo bonifico istantaneo</li>
                  </ul>
                  <div className="mt-3 text-sm"><span className="font-medium">Consiglio:</span> evita. Se vuoi, ti proponiamo alternative sicure.</div>
                </div>
                <a href={`https://t.me/${telegramUsername.replace('@','')}`} className="block w-full text-center rounded-xl px-5 py-3 bg-gray-900 text-white font-medium hover:bg-black transition">Apri chat Telegram</a>
                <div className="text-xs text-gray-500 text-center">Consegna via Telegram a {telegramUsername}</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="border-y bg-gray-50/50">
        <div className="mx-auto max-w-6xl px-4 py-6 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600">
          <div>⚡ Risposta &lt; 20 min</div>
          <div>🔐 Pagamenti Stripe</div>
          <div>💬 Report su Telegram</div>
          <div>🧠 Analisi umana + segnali tecnici</div>
        </div>
      </section>

      <section id="come-funziona" className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-2xl md:text-3xl font-bold">Come funziona</h2>
        <div className="mt-8 grid md:grid-cols-4 gap-6 text-sm">
          {[
            {step: '1', title: 'Scegli il pacchetto', desc: 'Lite, Report o Escort.'},
            {step: '2', title: 'Paga con Stripe', desc: 'Link rapido, nessuna registrazione.'},
            {step: '3', title: 'Invia il link su Telegram', desc: 'Profilo/annuncio/sito + dettagli.'},
            {step: '4', title: 'Verdetto chiaro', desc: 'OK / Rischio alto + consigli pratici.'},
          ].map((s) => (
            <div key={s.step} className="rounded-3xl border p-6">
              <div className="text-xs text-gray-500">Step {s.step}</div>
              <div className="mt-1 font-semibold">{s.title}</div>
              <p className="mt-2 text-gray-600">{s.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="prezzi" className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-2xl md:text-3xl font-bold">Prezzi trasparenti</h2>
        <p className="mt-2 text-gray-600">Paga con Stripe, poi inviaci il link su Telegram.</p>
        <div className="mt-8 grid md:grid-cols-3 gap-6">
          {[
            {name: 'SafeBuy Lite', price: '€4,99', badge: 'Controllo rapido', items: ['1 link/profilo', 'Verdetto Sì/No', '3 motivi principali'], pay: STRIPE_LITE},
            {name: 'SafeBuy Report', price: '€9,99', badge: 'Più scelto', items: ['Analisi completa', 'Segnali tecnici dominio/recensioni', 'Consigli e alternative sicure'], pay: STRIPE_STD},
            {name: 'SafeBuy Escort', price: '€14,99', badge: 'Premium', items: ['Tutto del Report', 'Come pagare in sicurezza', 'Messaggi tipo per trattare'], pay: STRIPE_VIP},
          ].map((p, i) => (
            <div key={p.name} className={`rounded-3xl border p-6 ${i===1 ? 'ring-2 ring-gray-900' : ''}`}>
              <div className="flex items-center justify-between">
                <div className="text-xl font-semibold">{p.name}</div>
                <span className="text-xs px-2 py-1 rounded-full bg-gray-100">{p.badge}</span>
              </div>
              <div className="mt-4 text-3xl font-bold">{p.price}<span className="text-base font-normal text-gray-500"> / verifica</span></div>
              <ul className="mt-4 text-sm text-gray-600 space-y-2">
                {p.items.map((it) => <li key={it}>• {it}</li>)}
              </ul>
              <div className="mt-6 grid grid-cols-2 gap-2">
                <a href={p.pay} target="_blank" rel="noreferrer" className="inline-flex w-full justify-center rounded-xl px-4 py-2 bg-gray-900 text-white font-medium hover:bg-black">Paga con Stripe</a>
                <a href={`https://t.me/${telegramUsername.replace('@','')}`} className="inline-flex w-full justify-center rounded-xl px-4 py-2 border font-medium hover:bg-gray-50">Invia su Telegram</a>
              </div>
              <div className="mt-2 text-xs text-gray-500 text-center">Niente abbonamenti • Rimborso 24h se non rispondiamo</div>
            </div>
          ))}
        </div>
      </section>

      <section id="faq" className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-2xl md:text-3xl font-bold">Domande frequenti</h2>
        <div className="mt-6 space-y-4">
          <details className="rounded-2xl border p-4">
            <summary className="font-medium">Cosa controllate esattamente?</summary>
            <p className="mt-2 text-gray-600">Segnali tecnici (dominio, HTTPS, età, contatti), social proof, incongruenze su prezzo/foto, metodi di pagamento. Non accediamo a dati privati.</p>
          </details>
          <details className="rounded-2xl border p-4">
            <summary className="font-medium">In quanto tempo ricevo il verdetto?</summary>
            <p className="mt-2 text-gray-600">Nella media meno di 20 minuti in orario 9–22. Se siamo offline, riceverai comunque risposta appena possibile.</p>
          </details>
          <details className="rounded-2xl border p-4">
            <summary className="font-medium">È una garanzia assoluta?</summary>
            <p className="mt-2 text-gray-600">No: è una valutazione esperta e prudenziale basata su segnali. La decisione finale resta tua. Usiamo best practice per ridurre il rischio.</p>
          </details>
          <details className="rounded-2xl border p-4">
            <summary className="font-medium">Rimborsi</summary>
            <p className="mt-2 text-gray-600">Se non ricevi un responso entro 24h dall’invio dei dati, rimborsiamo al 100% su richiesta. Se il link non è analizzabile, ti contattiamo per un’alternativa o rimborso.</p>
          </details>
        </div>
      </section>

      <section id="contatti" className="mx-auto max-w-6xl px-4 py-16">
        <div className="rounded-3xl border p-6">
          <h2 className="text-2xl md:text-3xl font-bold">Ordina e inviaci il link su Telegram</h2>
          <p className="mt-2 text-gray-600">Scrivici su Telegram, manda il link del sito/profilo/annuncio e i dettagli principali.</p>
          <div className="mt-6 grid md:grid-cols-3 gap-3">
            <a href={`https://t.me/${telegramUsername.replace('@','')}`} className="rounded-xl px-5 py-3 bg-gray-900 text-white font-medium text-center hover:bg-black">Apri chat Telegram</a>
            <a href="#prezzi" className="rounded-xl px-5 py-3 border font-medium text-center hover:bg-gray-50">Scegli un pacchetto</a>
            <a href="#faq" className="rounded-xl px-5 py-3 border font-medium text-center hover:bg-gray-50">Leggi le FAQ</a>
          </div>
          <div className="mt-4 text-xs text-gray-500">Confermando l’ordine accetti i Termini & Privacy.</div>
        </div>
      </section>

      <footer className="border-t">
        <div className="text-center text-xs text-gray-500 py-6">© {new Date().getFullYear()} SafeBuy Report. Tutti i diritti riservati.</div>
      </footer>
    </div>
  )
}
