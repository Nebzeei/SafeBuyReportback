import './globals.css'

export const metadata = {
  title: 'SafeBuy Report — Verifica venditori, siti e annunci prima di pagare',
  description: 'Analisi rapida via Telegram. Evita truffe su Subito, Marketplace, Vinted, Instagram. Pagamenti Stripe, report entro 20 minuti.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="it">
      <body className="antialiased bg-white text-gray-900">
        {children}
      </body>
    </html>
  )
}
